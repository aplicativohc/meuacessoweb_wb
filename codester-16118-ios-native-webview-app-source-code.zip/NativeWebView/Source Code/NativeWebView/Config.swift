//
//  Config.swift
//  NativeWebView
//
//  Created by Rafael Passos on 15/10/2019.
//  Copyright © 2019 Rafael Passos. All rights reserved.
//

import Foundation

struct Config {
    static let WEBAPP_URL = "YOUR WEBAPP URL"
    
    static let CLEAR_CACHE = false // Clear cache on start
    
    struct Theme {
        static let STATUS_BAR_BACKGROUND_COLOR = "#ffffff" // Status bar background color
    }
}
