//
//  ViewController.swift
//  NativeWebView
//
//  Created by Rafael Passos on 15/10/2019.
//  Copyright © 2019 Rafael Passos. All rights reserved.
//

import UIKit
import WebKit

class ViewController: UIViewController {

    @IBOutlet weak var webview: WKWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = UIColor(hex: Config.Theme.STATUS_BAR_BACKGROUND_COLOR)
        
        setupWebView()
        loadWebViewContent()
    }
    
    private func setupWebView() {
        if Config.CLEAR_CACHE {
            clearCache()
        }
                
        preventZooming()
    }
    
    private func clearCache() {
        let websiteDataTypes = NSSet(array: [WKWebsiteDataTypeDiskCache, WKWebsiteDataTypeMemoryCache])
        let date = Date(timeIntervalSince1970: 0)
        WKWebsiteDataStore.default().removeData(ofTypes: websiteDataTypes as! Set<String>, modifiedSince: date, completionHandler:{ })
    }
    
    private func preventZooming() {
        webview.scrollView.bounces = false
        webview.scrollView.bouncesZoom = false
        webview.scrollView.delegate = self
        
        let source: String = "var meta = document.createElement('meta');" +
            "meta.name = 'viewport';" +
            "meta.content = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no';" +
            "var head = document.getElementsByTagName('head')[0];" + "head.appendChild(meta);"

        let script: WKUserScript = WKUserScript(source: source, injectionTime: .atDocumentEnd, forMainFrameOnly: true)
        
        webview.configuration.userContentController.addUserScript(script)
    }
    
    private func loadWebViewContent() {
        if let url = URL(string: Config.WEBAPP_URL) {
            webview.load(URLRequest(url: url))
        }
    }

}

extension ViewController: UIScrollViewDelegate {
    
    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
        return nil
    }
    
    func scrollViewWillBeginZooming(_ scrollView: UIScrollView, with view: UIView?) {
       scrollView.pinchGestureRecognizer?.isEnabled = false
    }
    
}

